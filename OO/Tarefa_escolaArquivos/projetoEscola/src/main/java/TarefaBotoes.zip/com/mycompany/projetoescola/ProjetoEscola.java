package com.mycompany.projetoescola;
import classes.disciplina;
import Gui.FrProfessor;

public class ProjetoEscola {
    public static void main(String[] args) {
        FrProfessor tela = new FrProfessor ();
        tela.setVisible(true);
    }
    
}
